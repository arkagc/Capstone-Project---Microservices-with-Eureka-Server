package com.example.user_service.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.user_service.dto.BankAccountDTO;

@FeignClient(name = "BANK-ACCOUNT-SERVICE" , url = "http://localhost:8082")
public interface BankAcountServiceClient {
	
	@PostMapping("/bank")
    BankAccountDTO createBankAccount(@RequestBody BankAccountDTO bankAccountDTO);
	
	@GetMapping("/bank")
    List<BankAccountDTO> getAllBankAccounts();
	
    @GetMapping("/bank/{id}")
    BankAccountDTO getBankAccountById(@PathVariable int id);

    @PutMapping("/bank/{id}")
    BankAccountDTO updateBankAccountById(@PathVariable int id, @RequestBody BankAccountDTO bankAccountDTO);

    @DeleteMapping("/bank/{id}")
    void deleteBankAccountById(@PathVariable int id);

    @GetMapping("/bank/user/{id}")
	List<BankAccountDTO> getAccountsByUserId(@PathVariable int id);
}
