package com.example.user_service.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user_service.client.BankAcountServiceClient;
import com.example.user_service.dto.BankAccountDTO;
import com.example.user_service.dto.UserDTO;
import com.example.user_service.entity.User;
import com.example.user_service.repo.UserRepository;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
    private UserRepository userRepository;
	
	@Autowired
    private BankAcountServiceClient bankAcountServiceClient;
	
	// http://localhost:8081/user
	// http://localhost:8085/user
	@PostMapping
    public UserDTO createUser(@RequestBody UserDTO userDTO) {
        User user = new User();
        user.setName(userDTO.getName());
        user.setAddress(userDTO.getAddress());
        User savedUser = userRepository.save(user);

        userDTO.setId(savedUser.getId());
        
        List<BankAccountDTO> updatedBankAccounts = new ArrayList<>();
        for (BankAccountDTO accountDTO : userDTO.getListBankAccounts()) {
            accountDTO.setUserId(savedUser.getId());
            BankAccountDTO savedAccountDTO = bankAcountServiceClient.createBankAccount(accountDTO);
            updatedBankAccounts.add(savedAccountDTO);
        }
        userDTO.setListBankAccounts(updatedBankAccounts);
        return userDTO;
    }

	// http://localhost:8081/user/{id}
	// http://localhost:8085/user/{id}
	@GetMapping("/{id}")
    public UserDTO getUser(@PathVariable int id) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        
        List<BankAccountDTO> accounts = bankAcountServiceClient.getAccountsByUserId(id);

        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        userDTO.setName(user.getName());
        userDTO.setAddress(user.getAddress());
        userDTO.setListBankAccounts(accounts);
        
        return userDTO;
    }
	
	// http://localhost:8081/user
	// http://localhost:8085/user
    @GetMapping
    public List<UserDTO> getAllUsers() {
        List<User> users = userRepository.findAll();
        List<UserDTO> userDTOs = new ArrayList<>();

        for (User user : users) {
            List<BankAccountDTO> accounts = bankAcountServiceClient.getAccountsByUserId(user.getId());

            UserDTO userDTO = new UserDTO();
            userDTO.setId(user.getId());
            userDTO.setName(user.getName());
            userDTO.setAddress(user.getAddress());
            userDTO.setListBankAccounts(accounts);

            userDTOs.add(userDTO);
        }

        return userDTOs;
    }
    
    // http://localhost:8081/user/{userId}/bank/{bankAccountId}
    // http://localhost:8085/user/{userId}/bank/{bankAccountId}
    @PutMapping("/{userId}/bank/{bankAccountId}")
    public UserDTO updateUser(@PathVariable int userId, @PathVariable int bankAccountId, @RequestBody UserDTO userDTO) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        user.setName(userDTO.getName());
        user.setAddress(userDTO.getAddress());
        userRepository.save(user);
        
        BankAccountDTO existingAccount = bankAcountServiceClient.getBankAccountById(bankAccountId);
        if (existingAccount == null || existingAccount.getUserId() != userId) {
            throw new RuntimeException("Bank account with ID " + bankAccountId + " does not belong to user " + userId);
        }

        BankAccountDTO updatedAccount = null;
        for (BankAccountDTO accountDTO : userDTO.getListBankAccounts()) {
            if (accountDTO.getId() == bankAccountId) {
                updatedAccount = bankAcountServiceClient.updateBankAccountById(bankAccountId, accountDTO);
                break;
            }
        }

        if (updatedAccount == null) {
            throw new RuntimeException("Bank account details for ID " + bankAccountId + " were not provided in the request.");
        }

        UserDTO responseDTO = new UserDTO();
        responseDTO.setId(user.getId());
        responseDTO.setName(user.getName());
        responseDTO.setAddress(user.getAddress());
        responseDTO.setListBankAccounts(Collections.singletonList(updatedAccount));

        return responseDTO;
    }
    
    // http://localhost:8081/user/{id}
    // http://localhost:8085/user/{id}
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable int id) {
        userRepository.deleteById(id);
        
        bankAcountServiceClient.getAccountsByUserId(id).forEach(account -> {
            bankAcountServiceClient.deleteBankAccountById(account.getId());
        });
    }
}
