package com.example.bank_account_service.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bank_account_service.client.UserFeignClient;
import com.example.bank_account_service.dto.UserDTO;
import com.example.bank_account_service.entity.BankAccount;
import com.example.bank_account_service.service.BankAccountService;

import feign.FeignException;

@RestController
@RequestMapping("/bank")
public class BankAccountController {

	@Autowired
	private BankAccountService bankAccountService;
	
	@Autowired
    private UserFeignClient userFeignClient;
	
	
	// http://localhost:8082/bank 
	// http://localhost:8085/bank
	@PostMapping
    public BankAccount saveBankAccountData(@RequestBody BankAccount bankAccount) {
        int userId = bankAccount.getUserId();
        try {
            UserDTO user = userFeignClient.getUserById(userId);
            if (user == null) {
                throw new RuntimeException("User with ID " + userId + " does not exist.");
            }
        } catch (FeignException.NotFound e) {
            throw new RuntimeException("User with ID " + userId + " does not exist. Cannot create a bank account.");
        } catch (Exception e) {
            throw new RuntimeException("Error validating user existence: " + e.getMessage());
        }
        return bankAccountService.saveBankAccount(bankAccount);
    }
	
	
	// http://localhost:8082/bank
	// http://localhost:8085/bank
	@GetMapping()
	public List<BankAccount> getAllBankAccountData(){
		List<BankAccount> allBankAccountData = bankAccountService.getAllBankAccount();
		return allBankAccountData;
	}
	
	// http://localhost:8082/bank/{id}
	// http://localhost:8085/bank/{id}
	@GetMapping("/{id}")
	public Optional<BankAccount> getBankAccountDataById(@PathVariable int id) {
		Optional<BankAccount> bankAccountDataById = bankAccountService.getBankAccountById(id);
		return bankAccountDataById;
	}
	
	// http://localhost:8082/bank/{id}
	// http://localhost:8085/bank/{id}
	@PutMapping("/{id}")
	public BankAccount updateBankAccountData(@PathVariable int id, @RequestBody BankAccount bankAccount) {
		
		BankAccount existingAccount = bankAccountService.getBankAccountById(id).orElseThrow(() -> new RuntimeException("Bank account with ID " + id + " does not exist."));
	    
	    int userId = existingAccount.getUserId();
	   
	    try {
	        UserDTO user = userFeignClient.getUserById(userId);
	        if (user == null) {
	            throw new RuntimeException("User with ID " + userId + " does not exist.");
	        }
	    } catch (FeignException.NotFound e) {
	        throw new RuntimeException("User with ID " + userId + " does not exist.");
	    }
	    
	    existingAccount.setAccountNumber(bankAccount.getAccountNumber());
	    existingAccount.setAccountType(bankAccount.getAccountType());

	    return bankAccountService.saveBankAccount(existingAccount);
	}
	
	// http://localhost:8082/bank/{id}
	// http://localhost:8085/bank/{id}
	@DeleteMapping("/{id}")
	public void deleteBankAccountDataById(@PathVariable int id) {
		bankAccountService.deleteBankAccountById(id);
	}
	
	// http://localhost:8082/bank/user/{userId}
	// http://localhost:8085/bank/user/{userId}
	@GetMapping("/user/{userId}")
	public List<BankAccount> getBankAccountByUserId(@PathVariable int userId){
		List<BankAccount> byUserId = bankAccountService.findByUserId(userId);
		return byUserId;
	}
}
