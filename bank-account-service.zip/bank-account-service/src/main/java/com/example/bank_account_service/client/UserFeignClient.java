package com.example.bank_account_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.bank_account_service.dto.UserDTO;

@FeignClient(name = "USER-SERVICE", url = "http://localhost:8081")
public interface UserFeignClient {
	
	@GetMapping("/user/{id}")
    UserDTO getUserById(@PathVariable int id);
}